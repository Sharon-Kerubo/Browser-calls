<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\Projects\Microsoft\GOL\TriboreHealthWebsite\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>