<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Projects\Microsoft\GOL\TriboreHealthWebsite\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>